import Stripe from "stripe";
let _s: Stripe | null = null;
export const getStripe = () => (_s ??= new Stripe(process.env.STRIPE_SECRET_KEY!));
