"use client";
import { useEffect, useState } from "react";
import { browserClient } from "@/lib/supabase";
export default function Join() {
  const sb = browserClient();
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  const [code, setCode] = useState("");
  useEffect(() => { setCode(new URLSearchParams(location.search).get("invite") || ""); }, []);
  const submit = async () => {
    setMsg("Creando cuenta...");
    const r = await fetch("/api/join", { method: "POST", body: JSON.stringify({ code, email, password }) });
    const j = await r.json();
    if (!r.ok) return setMsg(j.error);
    const { error } = await sb.auth.signInWithPassword({ email, password });
    if (error) return setMsg(error.message);
    location.href = "/feed";
  };
  return (<main style={{padding:20,fontFamily:"sans-serif",maxWidth:360}}>
    <h1>Crear cuenta</h1>
    {!code && <p>Necesitas un enlace de invitación.</p>}
    <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} style={{display:"block",width:"100%",margin:"8px 0"}} />
    <input placeholder="Contraseña (mín. 8)" type="password" value={password} onChange={e => setPassword(e.target.value)} style={{display:"block",width:"100%",margin:"8px 0"}} />
    <button disabled={!code} onClick={submit}>Entrar</button>
    <p>{msg}</p>
  </main>);
}
