"use client";
import { useState } from "react";
import { browserClient } from "@/lib/supabase";
export default function Login() {
  const sb = browserClient();
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  const submit = async () => {
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error) return setMsg("Acceso denegado o revocado");
    const { data: p } = await sb.from("profiles").select("role").eq("id", data.user.id).single();
    location.href = p?.role === "admin" ? "/admin" : "/feed";
  };
  return (<main style={{padding:20,fontFamily:"sans-serif",maxWidth:360}}>
    <h1>Iniciar sesión</h1>
    <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} style={{display:"block",width:"100%",margin:"8px 0"}} />
    <input placeholder="Contraseña" type="password" value={password} onChange={e => setPassword(e.target.value)} style={{display:"block",width:"100%",margin:"8px 0"}} />
    <button onClick={submit}>Entrar</button><p>{msg}</p>
  </main>);
}
