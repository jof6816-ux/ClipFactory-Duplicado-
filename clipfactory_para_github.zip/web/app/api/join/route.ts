import { adminClient } from "@/lib/supabase";
// Registro solo con código de invitación de un solo uso.
export async function POST(req: Request) {
  const { code, email, password } = await req.json();
  if (!code || !email || !password || password.length < 8)
    return Response.json({ error: "Datos inválidos (contraseña mínimo 8)" }, { status: 400 });
  const admin = adminClient();

  // Reclama el código de forma atómica: solo funciona si aún no fue usado.
  const { data: inv } = await admin.from("invites")
    .update({ used_by: "00000000-0000-0000-0000-000000000000" })
    .eq("code", code).is("used_by", null).select().maybeSingle();
  if (!inv) return Response.json({ error: "Invitación inválida o ya usada" }, { status: 403 });

  const { data, error } = await admin.auth.admin.createUser({ email, password, email_confirm: true });
  if (error || !data.user) {
    await admin.from("invites").update({ used_by: null }).eq("code", code); // libera el código
    return Response.json({ error: error?.message || "No se pudo crear la cuenta" }, { status: 400 });
  }
  await admin.from("profiles").insert({ id: data.user.id, email, role: "guest", active: true,
    free_pass: process.env.REQUIRE_PAYMENT !== "true" });
  await admin.from("invites").update({ used_by: data.user.id }).eq("code", code);
  return Response.json({ ok: true });
}
