import { requireAdmin } from "@/lib/supabase";
export async function POST(req: Request) {
  const admin = await requireAdmin(req);
  if (!admin) return new Response("forbidden", { status: 403 });
  const code = crypto.randomUUID().slice(0, 8);
  await admin.from("invites").insert({ code });
  return Response.json({ link: `${new URL(req.url).origin}/join?invite=${code}` });
}
