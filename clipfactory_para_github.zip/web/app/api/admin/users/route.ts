import { requireAdmin } from "@/lib/supabase";
export async function POST(req: Request) {
  const admin = await requireAdmin(req);
  if (!admin) return new Response("forbidden", { status: 403 });
  const { data } = await admin.from("profiles").select("id,email,active,paid,free_pass,created_at")
    .neq("role", "admin").order("created_at", { ascending: false });
  return Response.json({ users: data || [] });
}
