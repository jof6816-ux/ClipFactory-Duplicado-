import { requireAdmin } from "@/lib/supabase";
import { getStripe } from "@/lib/stripe";
export async function POST(req: Request) {
  const admin = await requireAdmin(req);
  if (!admin) return new Response("forbidden", { status: 403 });
  const { userId, remove } = await req.json();
  const { data: p } = await admin.from("profiles").select("stripe_customer_id").eq("id", userId).single();
  await admin.from("profiles").update({ active: false, paid: false, free_pass: false }).eq("id", userId);
  // Cancela la suscripción para que no se le siga cobrando
  if (p?.stripe_customer_id) {
    const subs = await getStripe().subscriptions.list({ customer: p.stripe_customer_id, status: "active" });
    for (const s of subs.data) await getStripe().subscriptions.cancel(s.id);
  }
  await admin.auth.admin.updateUserById(userId, { ban_duration: "876000h" });
  if (remove) await admin.auth.admin.deleteUser(userId);
  return Response.json({ ok: true });
}
