import { adminClient } from "@/lib/supabase";
import { getStripe } from "@/lib/stripe";
export async function POST(req: Request) {
  const body = await req.text(); // cuerpo crudo: necesario para verificar la firma
  let event;
  try {
    event = getStripe().webhooks.constructEvent(body, req.headers.get("stripe-signature")!,
      process.env.STRIPE_WEBHOOK_SECRET!);
  } catch { return new Response("bad signature", { status: 400 }); }
  const admin = adminClient();
  if (event.type === "checkout.session.completed") {
    const s: any = event.data.object;
    await admin.from("profiles").update({ paid: true, stripe_customer_id: s.customer })
      .eq("id", s.client_reference_id);
  }
  if (event.type === "customer.subscription.updated" || event.type === "customer.subscription.deleted") {
    const sub: any = event.data.object;
    const ok = event.type === "customer.subscription.updated" && ["active", "trialing"].includes(sub.status);
    await admin.from("profiles").update({ paid: ok }).eq("stripe_customer_id", sub.customer);
  }
  return Response.json({ received: true });
}
