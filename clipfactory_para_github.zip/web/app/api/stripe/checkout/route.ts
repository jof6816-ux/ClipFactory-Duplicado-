import { adminClient } from "@/lib/supabase";
import { getStripe } from "@/lib/stripe";
export async function POST(req: Request) {
  const token = req.headers.get("authorization")?.replace("Bearer ", "");
  const { data } = await adminClient().auth.getUser(token || "");
  if (!data.user) return new Response("unauthorized", { status: 401 });
  const origin = new URL(req.url).origin;
  const session = await getStripe().checkout.sessions.create({
    mode: "subscription",
    line_items: [{ price: process.env.STRIPE_PRICE_ID!, quantity: 1 }],
    client_reference_id: data.user.id,
    customer_email: data.user.email,
    success_url: `${origin}/feed?paid=1`,
    cancel_url: `${origin}/feed`,
  });
  return Response.json({ url: session.url });
}
