"use client";
import { useEffect, useState } from "react";
import { browserClient } from "@/lib/supabase";
export default function Admin() {
  const sb = browserClient();
  const [users, setUsers] = useState<any[]>([]);
  const [link, setLink] = useState("");
  const [err, setErr] = useState("");
  const call = async (path: string, body?: any) => {
    const { data } = await sb.auth.getSession();
    const r = await fetch(path, { method: "POST", body: JSON.stringify(body || {}),
      headers: { authorization: `Bearer ${data.session?.access_token}` } });
    if (!r.ok) throw new Error(r.status === 403 ? "No eres admin o no has iniciado sesión" : "Error");
    return r.json();
  };
  const load = async () => { try { setUsers((await call("/api/admin/users")).users); } catch (e: any) { setErr(e.message); } };
  useEffect(() => { load(); }, []);
  return (<main style={{padding:20,fontFamily:"sans-serif"}}>
    <h1>Panel admin</h1>{err && <p style={{color:"red"}}>{err}</p>}
    <button onClick={async () => setLink((await call("/api/admin/invite")).link)}>Crear invitación</button>
    {link && <p>Comparte: <code>{link}</code></p>}
    <h2>Invitados</h2>
    {users.map(u => (<div key={u.id} style={{margin:"8px 0"}}>
      {u.email} — {!u.active ? "revocado" : u.paid ? "pagando" : u.free_pass ? "gratis" : "sin pago"}{" "}
      {u.active && <button onClick={async () => {
        if (confirm(`¿Eliminar acceso de ${u.email}?`)) { await call("/api/admin/revoke", { userId: u.id }); load(); } }}>Eliminar acceso</button>}
    </div>))}
  </main>);
}
