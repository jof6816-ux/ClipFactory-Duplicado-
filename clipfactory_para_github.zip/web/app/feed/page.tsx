"use client";
import { useEffect, useState } from "react";
import { browserClient } from "@/lib/supabase";
export default function Feed() {
  const sb = browserClient();
  const [clips, setClips] = useState<any[]>([]);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => { (async () => {
    const { data } = await sb.from("clips").select("*").order("published_at", { ascending: false });
    const withUrls = await Promise.all((data || []).map(async c => ({
      ...c, url: (await sb.storage.from("clips").createSignedUrl(c.storage_path, 3600)).data?.signedUrl })));
    setClips(withUrls); setLoaded(true);
  })(); }, []);
  const subscribe = async () => {
    const { data } = await sb.auth.getSession();
    const r = await fetch("/api/stripe/checkout", { method: "POST",
      headers: { authorization: `Bearer ${data.session?.access_token}` } });
    location.href = (await r.json()).url;
  };
  return (<main style={{padding:20,fontFamily:"sans-serif"}}>
    <h1>Clips</h1>
    {loaded && clips.length === 0 && (<p>Aún no hay clips o necesitas suscripción. <button onClick={subscribe}>Suscribirme</button></p>)}
    {clips.map(c => (<div key={c.id} style={{marginBottom:24}}>
      <video src={c.url} controls style={{maxWidth:320}} /><p style={{fontSize:12}}>{c.credit}</p></div>))}
  </main>);
}
