# ClipFactory FFmpeg Worker

Worker Python que consulta `processing_jobs` en Supabase, descarga el vídeo desde el bucket privado `uploads`, detecta cambios de escena con FFmpeg, crea hasta tres clips verticales y guarda el resultado en el bucket `clips`.

## Railway
- Root directory: `/workers`
- Builder: Dockerfile
- Dockerfile path: `Dockerfile`
- Required variables: `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`
- Optional variables: `INPUT_BUCKET=uploads`, `OUTPUT_BUCKET=clips`, `POLL_SECONDS=8`, `MAX_CLIPS_PER_VIDEO=3`, `CLIP_SECONDS=25`

`SUPABASE_SERVICE_KEY` debe ser una clave secreta de servidor y nunca debe exponerse al navegador.

Este motor realiza detección de transiciones visuales; no es análisis semántico por IA, no genera voz y no publica en redes sociales.
